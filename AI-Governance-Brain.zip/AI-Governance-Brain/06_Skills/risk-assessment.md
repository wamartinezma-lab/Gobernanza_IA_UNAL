# Skill: risk-assessment

## Cuándo usarlo
Cuando el usuario pida evaluar el riesgo de un sistema, agente, política o caso de uso de IA.

## Pasos
1. Describe el sistema/caso de forma neutral.
2. Evalúa contra los umbrales de [[Harm Prevention Thresholds]].
3. Activa los 4 agentes y recoge su visión del riesgo.
4. Clasifica el nivel de riesgo (0-3 según la tabla de umbrales).
5. Identifica controles existentes y controles faltantes (especialmente de AI IAM: identidad, privilegios, auditoría, contención).
6. Propón mitigaciones priorizadas.
7. Indica si se requiere deliberación formal completa.

## Salida
- Nivel de riesgo + justificación
- Posiciones de los agentes
- Controles recomendados
- Próximos pasos
