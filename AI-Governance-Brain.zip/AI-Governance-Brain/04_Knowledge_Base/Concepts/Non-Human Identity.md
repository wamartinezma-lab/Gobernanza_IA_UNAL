# Non-Human Identity (NHI)

## Definición
Identidad runtime a través de la cual se ejerce autoridad delegada de máquina en entornos mediados por IA.

## Importancia
En sistemas de agentes, la NHI se convierte en el sujeto primario de gobernanza, más que el usuario humano que originalmente lanzó el proceso.

## Principios asociados
- Identidad distinta y verificable
- Ciclo de vida separado del humano
- Atribución clara de acciones
- Control de delegación

## Enlaces
- [[AI_IAM_Standard]]
- [[Least Privilege]]
- [[Runtime Control Plane]]
