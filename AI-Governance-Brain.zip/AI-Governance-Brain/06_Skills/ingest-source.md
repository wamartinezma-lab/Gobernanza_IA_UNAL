# Skill: ingest-source

## Cuándo usarlo
Cuando el usuario entregue un documento, paper, PDF, nota o enlace y diga:
- "Ingiere esta fuente"
- "Añade esto al cerebro"
- "Procesa este documento"

## Pasos
1. Identifica los conceptos clave relacionados con gobernanza de IA, agentes, identidad, daño, cultura, igualdad, libertad o seguridad.
2. Crea o actualiza páginas en `04_Knowledge_Base/Concepts/` para los conceptos nuevos o importantes.
3. Enlaza esos conceptos con los 4 agentes y con los estándares existentes ([[AI_IAM_Standard]], [[NIST_Mapping]], etc.).
4. Guarda la referencia de la fuente original en `04_Knowledge_Base/Sources/` (título, autor, fecha, enlace o ruta).
5. Si el contenido es especialmente relevante, actualiza el [[Dashboard]].
6. Genera enlaces `[[wiki-style]]` generosos.

## Regla
Nunca modifiques el contenido original de la fuente. Solo crea capas de interpretación y conexión encima.
