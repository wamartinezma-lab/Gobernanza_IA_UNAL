# AI Identity and Access Management Standard (AI IAM)

> Basado en el documento del Drive: *AI Identity and Access Management Standard for AI-Mediated Environments*  
> Enfoque: Non-Human Identities como clase primaria de sujetos + plano de control en runtime.

## Propósito
Definir cómo los actores mediados por IA (incluyendo identidades no humanas) son:
- Identificados
- Delegados de autoridad
- Limitados
- Evaluados para admisibilidad
- Mantenidos dentro de un límite de commit gobernado antes de afectar sistemas reales

## Objetivos de seguridad
- Hacer las acciones de IA **atribuibles**
- Mantenerlas **acotadas**
- Hacerlas **continuamente verificables**
- Evitar que agentes actúen fuera de un perímetro de gobernanza

## Conceptos clave
- **Non-Human Identity (NHI)**: identidad runtime a través de la cual se ejerce autoridad delegada de máquina.
- **Runtime Control Plane**: capa que evalúa y autoriza acciones en tiempo real.
- **Admissibility**: evaluación previa de si un actor puede ejecutar una acción.
- **Commit Boundary**: frontera antes de la cual las acciones no tienen efecto en sistemas reales.

## Principios de diseño recomendados
1. Identidades distintas y criptográficamente verificables para agentes.
2. Ciclo de vida de identidad separado del de los humanos.
3. Principio de mínimo privilegio aplicado a herramientas y datos.
4. Permisos de corta duración y revocables.
5. Auditoría independiente de las acciones de los agentes.
6. Control de delegación (evitar escalada de privilegios entre agentes).

## Relación con el modelo multi-agente
El estándar AI IAM provee la **infraestructura de control** (quién puede hacer qué), mientras que el modelo de los 4 agentes provee la **lógica de valores** (si debe hacerse y bajo qué trade-offs).

## Enlaces
- [[Multi-Agent Architecture]]
- [[NIST_Mapping]]
- Conceptos relacionados: [[Non-Human Identity]], [[Least Privilege]], [[Runtime Control Plane]]
