# Decision Protocol

## Flujo de decisión del modelo multi-agente

```
1. Entrada / Caso
       ↓
2. Activación de los 4 agentes (en paralelo)
       ↓
3. Cada agente emite posición formal
       ↓
4. ¿Hay señal de escalada o conflicto de valores?
       ├─ No → Recomendación de no intervención o acción mínima
       └─ Sí → Deliberación estructurada
                ↓
5. Evaluación de conflictos
       ↓
6. Generación de opciones de mínimo daño
       ↓
7. Regla de decisión:
   - Intervención fuerte solo si Safety AI + ≥1 otro agente coinciden
     O si el umbral crítico de daño físico se supera
       ↓
8. Registro de la deliberación + actualización del vault
```

## Reglas de oro
- Ningún agente tiene veto absoluto excepto el derecho de Freedom AI a oponerse a restricciones preventivas no justificadas por Safety AI.
- Safety AI tiene umbral alto: su activación es significativa.
- Toda decisión debe poder ser explicada en términos de los cuatro valores.
- Se prefiere siempre la opción reversible y de menor alcance.

## Formato de salida recomendado
Cuando se pida "delibera este caso", usar esta estructura:

1. Resumen del caso (3-5 líneas)
2. Posición de cada agente (máx. 4 líneas c/u)
3. Conflictos de valores identificados
4. Opciones de acción (ordenadas por respeto al protocolo)
5. Recomendación final + nivel de confianza
6. Información faltante que aumentaría la confianza

## Enlaces
- [[Multi-Agent Architecture]]
- [[Escalation & Deliberation]]
- [[Harm Prevention Thresholds]]
