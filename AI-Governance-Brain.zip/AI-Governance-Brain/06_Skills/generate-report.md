# Skill: generate-report

## Cuándo usarlo
Cuando el usuario pida un reporte de gobernanza, evaluación formal o documento de salida.

## Pasos
1. Confirma el alcance y audiencia del reporte.
2. Recoge la información relevante del vault (Core Model + Insights + proyecto activo).
3. Estructura el reporte de forma clara:
   - Resumen ejecutivo
   - Contexto
   - Análisis multi-agente
   - Riesgos y umbrales
   - Recomendaciones
   - Apéndices / referencias
4. Usa lenguaje preciso y evita alarmismo injustificado.
5. Guarda el entregable final en la carpeta `Outputs/` del proyecto correspondiente.
