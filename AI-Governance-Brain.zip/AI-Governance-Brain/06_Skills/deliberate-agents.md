# Skill: deliberate-agents

## Cuándo usarlo
Cuando el usuario diga:
- "Delibera este caso"
- "Aplica el modelo de gobernanza"
- "Evalúa con los 4 agentes"
- O cualquier situación que requiera análisis de trade-offs de valores.

## Pasos
1. Resume el caso en 3-5 líneas claras.
2. Activa cada uno de los 4 agentes y escribe su posición (máximo 4 líneas cada uno):
   - [[Freedom_AI]]
   - [[Equality_AI]]
   - [[Safety_AI]]
   - [[Culture_AI]]
3. Identifica los conflictos de valores principales.
4. Propón 1-3 opciones de acción, ordenadas según el [[Decision Protocol]].
5. Indica nivel de confianza (alto / medio / bajo) y qué información faltaría para subirlo.
6. Si surge un patrón nuevo o aprendizaje importante, crea o actualiza una nota en `04_Knowledge_Base/Insights/`.

## Formato de salida obligatorio
Usar siempre la estructura definida en [[Decision Protocol]].
