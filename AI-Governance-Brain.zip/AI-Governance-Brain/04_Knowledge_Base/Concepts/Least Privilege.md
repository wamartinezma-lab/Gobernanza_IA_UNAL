# Least Privilege

## Definición
Principio según el cual cada agente o identidad solo debe tener los permisos mínimos necesarios para cumplir su tarea específica.

## Aplicación en agentes de IA
- Limitación de herramientas disponibles
- Limitación de acceso a datos
- Permisos de corta duración
- Revocación rápida

## Enlaces
- [[AI_IAM_Standard]]
- [[Non-Human Identity]]
- [[Runtime Control Plane]]
