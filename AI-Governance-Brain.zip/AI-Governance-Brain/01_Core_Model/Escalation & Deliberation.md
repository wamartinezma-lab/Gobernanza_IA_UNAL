# Escalation & Deliberation

## ¿Cuándo se activa la deliberación?
La deliberación estructurada se dispara cuando:
- Cualquiera de los 4 agentes genera una **señal de escalada**.
- Existe un conflicto claro entre dos o más valores.
- Se propone una acción que afecta de forma significativa a la libertad, igualdad, seguridad física o cultura.

## Proceso de deliberación
1. **Posicionamiento individual**: cada agente emite su análisis y recomendación.
2. **Mapeo de conflictos**: se identifican explícitamente los trade-offs.
3. **Búsqueda de soluciones de mínimo daño**: se priorizan opciones que preserven los cuatro valores en la mayor medida posible.
4. **Regla de decisión final**:
   - Intervención fuerte requiere apoyo de Safety AI + al menos otro agente, **o** superación del umbral crítico de daño físico.
   - En caso de empate o alta incertidumbre → se prioriza la opción que preserve más libertad y sea más reversible.

## Registro
Toda deliberación importante debe quedar registrada como nota en `04_Knowledge_Base/Insights/` o dentro del proyecto correspondiente, con enlaces a los agentes involucrados.

## Enlaces
- [[Decision Protocol]]
- [[Multi-Agent Architecture]]
- [[Freedom_AI]] · [[Equality_AI]] · [[Safety_AI]] · [[Culture_AI]]
