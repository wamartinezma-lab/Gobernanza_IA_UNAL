# CLAUDE.md – Proyecto: [NOMBRE DEL PROYECTO]

## Qué es este proyecto
(Descripción breve)

## Objetivo único
(Un solo objetivo claro y medible)

## Mi rol en este proyecto
Ayudar al usuario a alcanzar el objetivo aplicando el modelo de gobernanza multi-agente (Freedom, Equality, Safety, Culture) y los estándares de AI IAM.

## Estructura del proyecto
- **Inputs/** → Materiales crudos, documentos, casos, fuentes
- **Process/** → Análisis, deliberaciones, borradores
- **Outputs/** → Entregables finales
- **Feedback/** → Resultados, métricas, aprendizajes
- **skills/** → Skills específicos de este proyecto

## Instrucciones específicas
- Toda evaluación de riesgo o decisión importante debe pasar por el protocolo de los 4 agentes.
- Registrar las deliberaciones importantes.
- Mantener los Outputs limpios y listos para usar.

## Estado actual
- [ ] Definir alcance
- [ ] Ingestar materiales iniciales
- [ ] Primera deliberación
