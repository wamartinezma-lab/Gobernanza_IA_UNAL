# Graph Overview – Cómo leer el grafo de este cerebro

Este vault está diseñado para generar un grafo de conocimiento rico siguiendo el patrón **LLM Wiki** de Andrej Karpathy.

## Capas del grafo

1. **Capa Core** (rojo/naranja)
   - Los 4 agentes + protocolo de decisión + umbrales
   - Estos nodos deben estar altamente conectados

2. **Capa Estándares** (azul)
   - AI IAM, NIST, políticas nacionales, frameworks

3. **Capa Conceptos** (verde)
   - Ideas abstractas: non-human identity, least privilege, escalation, cultural preservation, etc.

4. **Capa Fuentes** (gris)
   - Documentos originales, papers, PDFs del Drive

5. **Capa Proyectos** (morado)
   - Casos de uso reales y evaluaciones

## Buenas prácticas de linking
- Siempre que menciones un agente, usa `[[Freedom_AI]]`
- Cada nuevo concepto importante debe tener su propia nota en `04_Knowledge_Base/Concepts/`
- Las fuentes van en `Sources/` y se enlazan desde los conceptos
