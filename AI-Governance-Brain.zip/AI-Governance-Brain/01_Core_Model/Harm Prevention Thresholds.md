# Harm Prevention Thresholds

## Principio rector
Safety AI solo se activa ante **daño físico inminente + alta probabilidad**.

## Definiciones operativas

### Daño físico
- Lesión corporal, muerte, daño grave a la integridad física de personas.
- Incluye daños a infraestructura crítica que puedan causar daño físico de forma directa y previsible (ej. sistemas de energía, transporte, salud).

### Inminente
- Ventana temporal corta.
- Cadena causal clara y corta entre la acción del sistema y el daño.

### Alta probabilidad
- Evidencia empírica sólida, o
- Modelo robusto y validado que indique probabilidad elevada.
- No basta con "podría pasar" o escenarios de cola larga sin base empírica.

## Niveles de respuesta sugeridos

| Nivel | Condición | Respuesta típica |
|-------|-----------|------------------|
| 0 | Sin daño físico inminente | No intervención / monitoreo |
| 1 | Riesgo físico bajo o lejano | Advertencia + diseño de mitigaciones |
| 2 | Riesgo físico moderado y plausible | Contención reversible + supervisión humana |
| 3 | Daño físico inminente + alta probabilidad | Intervención prioritaria (Safety AI + apoyo) |

## Notas importantes
- El daño psicológico, reputacional, moral o cultural se gestiona principalmente a través de Freedom AI, Equality AI y Culture AI, no mediante activación de Safety AI.
- Los umbrales deben revisarse periódicamente con evidencia nueva.

## Enlaces
- [[Safety_AI]]
- [[Decision Protocol]]
- [[Multi-Agent Architecture]]
