# AI-Governance-Brain

**Cerebro Digital de Gobernanza de la IA**  
Configuración completa lista para usar con Claude Desktop + Obsidian (patrón Second Brain / LLM Wiki de Karpathy).

## Contenido
- Modelo multi-agente completo (Freedom, Equality, Safety, Culture)
- Protocolo de decisión y umbrales de daño
- Estándar AI IAM y mapeo NIST
- Skills listos: deliberate-agents, ingest-source, risk-assessment, generate-report
- Estructura de proyectos con Inputs / Process / Outputs / Feedback
- Dashboard y guía de grafo

## Cómo activarlo

1. Descomprime esta carpeta donde quieras guardar tu vault.
2. Ábrela con Obsidian (Open folder as vault).
3. Instala el plugin **Local REST API** y copia la API Key.
4. En Claude Desktop (pestaña Code) ejecuta el comando MCP con tu key (ver guía original).
5. Di a Claude:

```
Estás configurando mi Cerebro Digital de Gobernanza de IA. 
Lee el CLAUDE.md y la carpeta 01_Core_Model. 
Luego intervíame UNA pregunta a la vez para completar mi perfil.
```

## Origen
Basado en:
- La guía "How to Build an AI Second Brain With Claude and Obsidian"
- El modelo Multi-Agent AI Governance for Harm Prevention and Cultural Preservation
- El AI Identity and Access Management Standard
- Principios NIST de identidad de agentes

---
Listo para crecer contigo.
