# Runtime Control Plane

## Definición
Capa de control que evalúa y autoriza (o bloquea) las acciones de los agentes de IA en tiempo real, antes de que estas afecten sistemas reales.

## Función
- Evaluación de admisibilidad
- Aplicación de políticas
- Logging y auditoría
- Contención

## Relación con el modelo
El Runtime Control Plane es la infraestructura que hace posible aplicar las decisiones del protocolo multi-agente de forma efectiva.

## Enlaces
- [[AI_IAM_Standard]]
- [[Non-Human Identity]]
- [[Decision Protocol]]
