# Mapeo con principios NIST (Agent Identity & Authorization)

## Resumen
NIST ha propuesto principios de diseño para sistemas de gestión de identidad de agentes de IA. Este archivo sirve para mapear esos principios con el modelo de los 4 agentes y el estándar AI IAM.

## Principios clave de NIST (síntesis)
1. Identificación distinta de agentes (separada de usuarios humanos y service accounts).
2. Ciclo de vida de identidad propio.
3. Autenticación y autorización robustas.
4. Permisos de mínimo privilegio y alcance limitado.
5. Autorizaciones de corta duración y revocables.
6. Trazabilidad y auditoría independiente.
7. Control de delegación y prevención de escalada de privilegios.
8. Supervisión humana en acciones de alto riesgo.
9. Monitoreo continuo.
10. Capacidad de contención / revocación rápida.

## Mapeo con este cerebro
| Principio NIST | Elemento del cerebro |
|--------------|----------------------|
| Identidad distinta de agentes | [[AI_IAM_Standard]] + Non-Human Identity |
| Mínimo privilegio | Runtime Control Plane + Least Privilege |
| Supervisión humana en alto riesgo | Activación de [[Safety_AI]] + Human-in/on-the-loop |
| Contención rápida | Decision Protocol + umbrales de daño |
| Auditoría | Registro de deliberaciones + Insights |

## Enlaces
- [[AI_IAM_Standard]]
- [[Safety_AI]]
- [[Decision Protocol]]
